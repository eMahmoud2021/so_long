/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   utile1.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: memam <memam@student.42mulhouse.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/20 14:38:27 by memam             #+#    #+#             */
/*   Updated: 2022/07/22 14:49:26 by memam            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/my_game.h"

int	sortie_exit(t_param *param)
{
	int		y;
	int		x;

	y = param->player_y;
	x = param->player_x;
	if (param->map[y][x] == 'E' && param->c == 0)
	{
		param->map[y][x + 1] = '0';
		param->success = 1;
		free_all_exit(param);
	}
	return (0);
}

/***
int	*move_enn(t_param *param)
{
	int		y;
	int		x;

	y = param->player_y;
	x = param->player_x;
	if (param->map[y][x] == '0' || param->map[y][x] == 'C')
	{
		ft_printf("hi loop\n");
		if (param->map[y][x] == 'B')
		{
			y++;
			param->map[y][x] = 'B';
		}
		if (param->map[y][x] == 'G' )
		{		
			y--;
			param->map[y][x] = 'G';
		}
	}
	return (0);
}
*****/